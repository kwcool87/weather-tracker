# ⛅ Weather Forecast Accuracy Tracker — ZIP 47341

Fully automated daily weather forecast verification system.  
Runs at **8 AM ET every day** via GitHub Actions — no computer required.

---

## What It Does

Every morning at 8 AM:
1. Searches **Weather Underground**, **Weather.com**, and **AccuWeather** for ZIP 47341 forecasts
2. Pulls High/Low temp, Cloud Cover %, Precip Probability, and Precip Amount for each day
3. Fetches **yesterday's actual conditions** from weather history
4. Saves everything to this repo
5. **Sends a push notification to your phone** via the ntfy app

Over time the dashboard shows how each source's accuracy changes by lead time (1-day-out vs 7-day-out, etc.).

---

## One-Time Setup (~10 minutes)

### Step 1 — Create a GitHub account
Go to [github.com](https://github.com) and sign up (free).

### Step 2 — Create a new repository
1. Click **+** → **New repository**
2. Name it `weather-tracker` (or anything you like)
3. Set it to **Public** (required for free GitHub Pages)
4. Click **Create repository**

### Step 3 — Upload these files
Drag and drop all files from this folder into the repo:
- `fetch_weather.py`
- `index.html`
- `data/forecasts.json`
- `data/actuals.json`
- `.github/workflows/weather-fetch.yml`  ← create this path manually in GitHub

To create the workflow file in GitHub:
1. Click **Add file** → **Create new file**
2. Type the name: `.github/workflows/weather-fetch.yml`
3. Paste the contents of that file
4. Click **Commit changes**

### Step 4 — Add your Anthropic API key
1. In your repo, go to **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `ANTHROPIC_API_KEY`
4. Value: your Anthropic API key (from [console.anthropic.com](https://console.anthropic.com))
5. Click **Add secret**

### Step 5 — Set up phone notifications (ntfy)

**On your phone:**
1. Install the **ntfy** app ([Android](https://play.google.com/store/apps/details?id=io.heckel.ntfy) / [iOS](https://apps.apple.com/us/app/ntfy/id1625396347))
2. Open the app → tap **+** → Subscribe to topic
3. Enter a topic name — **make it unique**, something like `wx47341_yourname`
4. Tap **Subscribe**

**In GitHub:**
1. Go back to **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `NTFY_TOPIC`
4. Value: the exact topic name you entered in the app (e.g. `wx47341_yourname`)
5. Click **Add secret**

### Step 6 — Enable GitHub Pages (for the dashboard)
1. Go to **Settings** → **Pages**
2. Under **Source**, select **Deploy from a branch**
3. Branch: `main`, folder: `/ (root)`
4. Click **Save**
5. After ~2 minutes your dashboard will be live at:  
   `https://YOUR_GITHUB_USERNAME.github.io/weather-tracker/`

### Step 7 — Test it right now
1. Go to **Actions** tab in your repo
2. Click **Daily Weather Fetch**
3. Click **Run workflow** → **Run workflow**
4. Watch it run (takes 3–5 minutes)
5. Check your phone for the notification
6. Open the dashboard URL to see the data

---

## Schedule

The workflow runs at **8 AM ET** (two cron jobs handle the EST/EDT shift):
- `0 12 * * *` = 8 AM EDT (summer, March–November)  
- `0 13 * * *` = 8 AM EST (winter, November–March)

A deduplication check ensures it only runs once per day even if both triggers fire.

---

## Dashboard

Once GitHub Pages is enabled, your live dashboard is at:  
`https://YOUR_GITHUB_USERNAME.github.io/weather-tracker/`

**Tabs:**
- **Overview** — accuracy scorecards + MAE-by-lead-day charts for all 3 sources
- **Forecasts** — browse the logged forecast grid for any date
- **Evolution** — see how each source's forecast for a specific target date changed over time
- **Actuals** — all historical observed conditions on file

---

## File Structure

```
weather-tracker/
├── .github/
│   └── workflows/
│       └── weather-fetch.yml    ← GitHub Actions schedule
├── data/
│   ├── forecasts.json           ← all forecast snapshots (auto-updated daily)
│   ├── actuals.json             ← all observed actuals (auto-updated daily)
│   └── meta.json                ← last run timestamp
├── fetch_weather.py             ← Python fetch script
├── index.html                   ← dashboard (GitHub Pages)
└── README.md
```

---

## Troubleshooting

**No notification received:**  
- Double-check the `NTFY_TOPIC` secret matches exactly what you subscribed to in the app
- Make sure notifications are allowed for the ntfy app on your phone
- Check the Actions tab for any error messages

**Workflow fails:**  
- Check the Actions tab → click the failed run → expand the "Run weather fetch" step to see the error
- Most common cause: invalid or missing `ANTHROPIC_API_KEY`

**Dashboard shows no data:**  
- GitHub Pages can take 2–3 minutes to deploy after setup
- Make sure `data/forecasts.json` and `data/actuals.json` exist in the repo

**Data seems wrong or missing for a source:**  
- Weather sites occasionally restructure their pages; the AI search adapts but may miss a fetch
- The workflow will retry the next day automatically
- Error details appear in the ntfy notification and in the Actions log
